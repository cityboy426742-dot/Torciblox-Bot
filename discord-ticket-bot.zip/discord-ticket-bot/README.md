# Discord Ticket Bot

Sistema de tickets completo em discord.js v14: menu de usuário (abertura por categoria),
menu de staff (assumir / adicionar membro / fechar), transcript automático em HTML e
banco de dados SQLite local (zero configuração de banco externo).

## 1. Criar a aplicação no Discord

1. Acesse https://discord.com/developers/applications e crie uma aplicação.
2. Em **Bot**, clique em "Reset Token" e copie o token.
3. Ative os **Privileged Gateway Intents**: `Server Members Intent` e `Message Content Intent`.
4. Em **OAuth2 > URL Generator**, marque `bot` e `applications.commands`, e nas permissões
   marque: `Manage Channels`, `Manage Roles`, `Send Messages`, `Read Message History`,
   `Attach Files`, `Embed Links`. Use a URL gerada para convidar o bot ao seu servidor.

## 2. Configurar variáveis de ambiente

Copie `.env.example` para `.env` e preencha:

```
DISCORD_TOKEN=seu_token
CLIENT_ID=id_da_aplicacao
GUILD_ID=   # opcional, deixe vazio para comandos globais
```

## 3. Instalar e rodar localmente

```bash
npm install
npm run deploy   # registra os slash commands
npm start        # inicia o bot
```

## 4. Rodar em Pterodactyl

- Egg recomendado: **Node.js** (qualquer versão >= 18).
- Startup command: `npm install && npm run deploy && npm start` (ou separe em duas execuções:
  rode `npm run deploy` uma vez, depois deixe apenas `npm start` no startup).
- Faça upload de todos os arquivos deste projeto (exceto `node_modules`) e configure as
  variáveis de ambiente (`DISCORD_TOKEN`, `CLIENT_ID`, `GUILD_ID`) na aba **Startup/Variables** do painel.
- `better-sqlite3` compila um binário nativo no primeiro `npm install` — o egg padrão de Node
  do Pterodactyl já vem com as ferramentas necessárias (`python3`, `make`, `g++`).

## 5. Rodar no Railway

- Crie um novo projeto a partir do repositório (GitHub) ou faça upload via CLI (`railway up`).
- Defina as variáveis de ambiente em **Variables**.
- Start command: `npm run deploy && npm start` (ou rode o deploy manualmente uma vez via
  `railway run npm run deploy`).
- ⚠️ Railway usa filesystem efêmero por padrão em alguns planos — se quiser persistir os
  arquivos `data/bot.sqlite` e a pasta `transcripts/`, adicione um **Volume** apontando para
  a raiz do projeto (ou para `/data`, ajustando o caminho em `src/database/db.js` e
  `src/utils/transcript.js`).

## 6. Configurar o bot dentro do Discord

Depois do bot online, um administrador roda, em qualquer canal do servidor:

```
/ticket-config staff-role cargo:@Suporte
/ticket-config categoria categoria:🎫 Tickets
/ticket-config log-channel canal:#ticket-logs
/ticket-painel
```

Isso posta o painel com o menu de seleção de categorias. Qualquer membro pode escolher uma
categoria para abrir um ticket privado.

## Estrutura do projeto

```
src/
  commands/        -> slash commands (/ticket-config, /ticket-painel)
  events/           -> eventos do client (ready, interactionCreate)
  handlers/         -> lógica de criar/assumir/fechar ticket e adicionar membro
  utils/            -> embeds reutilizáveis e gerador de transcript HTML
  database/db.js    -> camada SQLite (better-sqlite3)
  config/categories.js -> categorias exibidas no menu (edite à vontade)
```

## Sobre os transcripts em nuvem

Por padrão, o transcript é salvo em `transcripts/*.html` e anexado como arquivo no canal
de log configurado. Para hospedar publicamente (como
`transcripts.swaggergroup.com.br/transcripts/...`), você precisa de um servidor web próprio
(Nginx, S3 + CloudFront, etc). O ponto de extensão já está marcado como `UPLOAD_HOOK` dentro
de `src/utils/transcript.js` — é só plugar sua função de upload ali para subir o HTML
automaticamente e usar a URL pública no embed de log em vez do anexo.

## Próximos sistemas (roadmap sugerido)

Este é o primeiro módulo do bot completo pedido. Os próximos a implementar, na ordem que
fizer mais sentido pra você: Verificação com Captcha, Sistema de Logs (entrou/saiu/protect),
Whitelist com aprovação automática/manual, Painel de Gerenciamento web, Sorteios,
Lembretes, Boas-vindas, Status em tempo real, PIX, Status de servidor, Rename via webhook,
Sugestões, `/dm /say /embed`.
