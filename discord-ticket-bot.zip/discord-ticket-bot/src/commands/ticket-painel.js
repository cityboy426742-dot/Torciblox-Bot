const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { panelEmbed, panelSelectRow } = require("../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ticket-painel")
    .setDescription("Envia o painel de abertura de tickets neste canal")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    await interaction.channel.send({
      embeds: [panelEmbed()],
      components: [panelSelectRow()],
    });
    await interaction.reply({ content: "✅ Painel enviado.", ephemeral: true });
  },
};
