const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  EmbedBuilder,
} = require("discord.js");
const db = require("../database/db");
const { COLOR } = require("../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ticket-config")
    .setDescription("Configura o sistema de tickets do servidor")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName("staff-role")
        .setDescription("Define o cargo de staff que atende tickets")
        .addRoleOption((opt) =>
          opt.setName("cargo").setDescription("Cargo da equipe").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("categoria")
        .setDescription("Define a categoria do Discord onde os tickets serão criados")
        .addChannelOption((opt) =>
          opt
            .setName("categoria")
            .setDescription("Categoria de canais")
            .addChannelTypes(ChannelType.GuildCategory)
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("log-channel")
        .setDescription("Define o canal onde os transcripts e logs serão enviados")
        .addChannelOption((opt) =>
          opt
            .setName("canal")
            .setDescription("Canal de texto para logs")
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub.setName("ver").setDescription("Mostra a configuração atual do sistema de tickets")
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === "staff-role") {
      const role = interaction.options.getRole("cargo");
      db.upsertGuildConfig(interaction.guildId, { staff_role_id: role.id });
      return interaction.reply({
        content: `✅ Cargo de staff definido como ${role}.`,
        ephemeral: true,
      });
    }

    if (sub === "categoria") {
      const category = interaction.options.getChannel("categoria");
      db.upsertGuildConfig(interaction.guildId, { ticket_category_id: category.id });
      return interaction.reply({
        content: `✅ Categoria de tickets definida como **${category.name}**.`,
        ephemeral: true,
      });
    }

    if (sub === "log-channel") {
      const channel = interaction.options.getChannel("canal");
      db.upsertGuildConfig(interaction.guildId, { log_channel_id: channel.id });
      return interaction.reply({
        content: `✅ Canal de logs/transcripts definido como ${channel}.`,
        ephemeral: true,
      });
    }

    if (sub === "ver") {
      const config = db.getGuildConfig(interaction.guildId);
      const embed = new EmbedBuilder()
        .setColor(COLOR)
        .setTitle("Configuração do Sistema de Tickets")
        .addFields(
          {
            name: "Cargo de Staff",
            value: config?.staff_role_id ? `<@&${config.staff_role_id}>` : "Não definido",
          },
          {
            name: "Categoria de Tickets",
            value: config?.ticket_category_id
              ? `<#${config.ticket_category_id}>`
              : "Não definida",
          },
          {
            name: "Canal de Logs",
            value: config?.log_channel_id ? `<#${config.log_channel_id}>` : "Não definido",
          }
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
