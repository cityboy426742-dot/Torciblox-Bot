const path = require("node:path");
const fs = require("node:fs");
const Database = require("better-sqlite3");

const dataDir = path.join(__dirname, "..", "..", "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, "bot.sqlite"));
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS guild_config (
    guild_id TEXT PRIMARY KEY,
    staff_role_id TEXT,
    ticket_category_id TEXT,
    log_channel_id TEXT
  );

  CREATE TABLE IF NOT EXISTS tickets (
    channel_id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    category TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open', -- open | claimed | closed
    claimed_by TEXT,
    created_at INTEGER NOT NULL,
    closed_at INTEGER,
    closed_by TEXT,
    ticket_number INTEGER
  );

  CREATE TABLE IF NOT EXISTS guild_ticket_counter (
    guild_id TEXT PRIMARY KEY,
    counter INTEGER NOT NULL DEFAULT 0
  );
`);

// ---------- guild_config helpers ----------
function getGuildConfig(guildId) {
  const row = db
    .prepare("SELECT * FROM guild_config WHERE guild_id = ?")
    .get(guildId);
  return row || null;
}

function upsertGuildConfig(guildId, fields) {
  const existing = getGuildConfig(guildId);
  if (!existing) {
    db.prepare(
      `INSERT INTO guild_config (guild_id, staff_role_id, ticket_category_id, log_channel_id)
       VALUES (@guild_id, @staff_role_id, @ticket_category_id, @log_channel_id)`
    ).run({
      guild_id: guildId,
      staff_role_id: fields.staff_role_id ?? null,
      ticket_category_id: fields.ticket_category_id ?? null,
      log_channel_id: fields.log_channel_id ?? null,
    });
  } else {
    const merged = { ...existing, ...fields };
    db.prepare(
      `UPDATE guild_config SET staff_role_id = @staff_role_id,
        ticket_category_id = @ticket_category_id,
        log_channel_id = @log_channel_id
       WHERE guild_id = @guild_id`
    ).run({
      guild_id: guildId,
      staff_role_id: merged.staff_role_id,
      ticket_category_id: merged.ticket_category_id,
      log_channel_id: merged.log_channel_id,
    });
  }
}

// ---------- tickets helpers ----------
function nextTicketNumber(guildId) {
  const row = db
    .prepare("SELECT counter FROM guild_ticket_counter WHERE guild_id = ?")
    .get(guildId);
  const next = (row?.counter ?? 0) + 1;
  db.prepare(
    `INSERT INTO guild_ticket_counter (guild_id, counter) VALUES (?, ?)
     ON CONFLICT(guild_id) DO UPDATE SET counter = excluded.counter`
  ).run(guildId, next);
  return next;
}

function createTicket({ channelId, guildId, userId, category, ticketNumber }) {
  db.prepare(
    `INSERT INTO tickets (channel_id, guild_id, user_id, category, status, created_at, ticket_number)
     VALUES (?, ?, ?, ?, 'open', ?, ?)`
  ).run(channelId, guildId, userId, category, Date.now(), ticketNumber);
}

function getTicket(channelId) {
  return db.prepare("SELECT * FROM tickets WHERE channel_id = ?").get(channelId) || null;
}

function claimTicket(channelId, staffId) {
  db.prepare(
    `UPDATE tickets SET status = 'claimed', claimed_by = ? WHERE channel_id = ?`
  ).run(staffId, channelId);
}

function closeTicket(channelId, staffId) {
  db.prepare(
    `UPDATE tickets SET status = 'closed', closed_by = ?, closed_at = ? WHERE channel_id = ?`
  ).run(staffId, Date.now(), channelId);
}

function getOpenTicketByUser(guildId, userId, category) {
  return db
    .prepare(
      `SELECT * FROM tickets WHERE guild_id = ? AND user_id = ? AND category = ? AND status != 'closed'`
    )
    .get(guildId, userId, category);
}

module.exports = {
  db,
  getGuildConfig,
  upsertGuildConfig,
  nextTicketNumber,
  createTicket,
  getTicket,
  claimTicket,
  closeTicket,
  getOpenTicketByUser,
};
