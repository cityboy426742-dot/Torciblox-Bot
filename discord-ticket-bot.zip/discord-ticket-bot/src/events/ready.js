const { ActivityType } = require("discord.js");

module.exports = {
  name: "ready",
  once: true,
  execute(client) {
    console.log(`✅ Bot online como ${client.user.tag}`);
    client.user.setPresence({
      activities: [{ name: "tickets | /ticket-painel", type: ActivityType.Watching }],
      status: "online",
    });
  },
};
