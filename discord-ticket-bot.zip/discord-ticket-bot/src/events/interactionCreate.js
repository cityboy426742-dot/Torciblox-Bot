const { handleCreateTicket } = require("../handlers/createTicket");
const { handleClaimTicket } = require("../handlers/claimTicket");
const { handleCloseButton, handleCloseModalSubmit } = require("../handlers/closeTicket");
const { handleAddMemberButton, handleAddMemberSelect } = require("../handlers/addMember");

module.exports = {
  name: "interactionCreate",
  async execute(interaction) {
    try {
      // Slash commands
      if (interaction.isChatInputCommand()) {
        const command = interaction.client.commands.get(interaction.commandName);
        if (!command) return;
        return command.execute(interaction);
      }

      // Menu Usuário: abrir ticket
      if (interaction.isStringSelectMenu() && interaction.customId === "ticket_create_menu") {
        return handleCreateTicket(interaction);
      }

      // Menu Staff: adicionar membro (select de usuário)
      if (interaction.isUserSelectMenu() && interaction.customId === "ticket_add_member_select") {
        return handleAddMemberSelect(interaction);
      }

      // Botões
      if (interaction.isButton()) {
        if (interaction.customId === "ticket_claim") return handleClaimTicket(interaction);
        if (interaction.customId === "ticket_close") return handleCloseButton(interaction);
        if (interaction.customId === "ticket_add_member")
          return handleAddMemberButton(interaction);
        if (interaction.customId.startsWith("feedback_")) {
          const [, channelId, score] = interaction.customId.split("_");
          return interaction.reply({
            content: `Obrigado pela sua avaliação (nota ${score}/5)! 🙏`,
            ephemeral: true,
          });
        }
      }

      // Modal de fechamento
      if (interaction.isModalSubmit() && interaction.customId === "ticket_close_modal") {
        return handleCloseModalSubmit(interaction);
      }
    } catch (err) {
      console.error("Erro ao processar interação:", err);
      const payload = {
        content: "❌ Ocorreu um erro ao processar essa ação.",
        ephemeral: true,
      };
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp(payload).catch(() => null);
      } else {
        await interaction.reply(payload).catch(() => null);
      }
    }
  },
};
