const {
  ActionRowBuilder,
  UserSelectMenuBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require("discord.js");
const db = require("../database/db");
const { COLOR } = require("../utils/embeds");

async function handleAddMemberButton(interaction) {
  const ticket = db.getTicket(interaction.channel.id);
  if (!ticket) {
    return interaction.reply({
      content: "Este canal não é um ticket válido.",
      ephemeral: true,
    });
  }

  const guildConfig = db.getGuildConfig(interaction.guildId);
  const isStaff = interaction.member.roles.cache.has(guildConfig?.staff_role_id);
  if (!isStaff) {
    return interaction.reply({
      content: "Apenas a equipe pode adicionar membros ao ticket.",
      ephemeral: true,
    });
  }

  const select = new UserSelectMenuBuilder()
    .setCustomId("ticket_add_member_select")
    .setPlaceholder("Selecione o membro para adicionar")
    .setMinValues(1)
    .setMaxValues(1);

  await interaction.reply({
    content: "Selecione o membro que deseja adicionar a este ticket:",
    components: [new ActionRowBuilder().addComponents(select)],
    ephemeral: true,
  });
}

async function handleAddMemberSelect(interaction) {
  const targetId = interaction.values[0];
  await interaction.channel.permissionOverwrites.edit(targetId, {
    ViewChannel: true,
    SendMessages: true,
    ReadMessageHistory: true,
  });

  await interaction.update({
    content: `✅ <@${targetId}> foi adicionado ao ticket.`,
    components: [],
  });

  await interaction.channel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(COLOR)
        .setDescription(`➕ <@${targetId}> foi adicionado ao ticket por ${interaction.user}.`),
    ],
  });
}

module.exports = { handleAddMemberButton, handleAddMemberSelect };
