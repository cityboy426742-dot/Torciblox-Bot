const { ChannelType, PermissionFlagsBits } = require("discord.js");
const categories = require("../config/categories");
const db = require("../database/db");
const { ticketWelcomeEmbed, ticketControlRow } = require("../utils/embeds");

async function handleCreateTicket(interaction) {
  const categoryId = interaction.values[0];
  const category = categories.find((c) => c.id === categoryId);
  if (!category) {
    return interaction.reply({ content: "Categoria inválida.", ephemeral: true });
  }

  const guildConfig = db.getGuildConfig(interaction.guildId);
  if (!guildConfig?.staff_role_id) {
    return interaction.reply({
      content:
        "⚠️ O bot ainda não foi configurado. Peça a um administrador para rodar `/ticket-config`.",
      ephemeral: true,
    });
  }

  const existing = db.getOpenTicketByUser(
    interaction.guildId,
    interaction.user.id,
    categoryId
  );
  if (existing) {
    const channel = interaction.guild.channels.cache.get(existing.channel_id);
    if (channel) {
      return interaction.reply({
        content: `Você já possui um ticket aberto nessa categoria: ${channel}`,
        ephemeral: true,
      });
    }
  }

  await interaction.deferReply({ ephemeral: true });

  const ticketNumber = db.nextTicketNumber(interaction.guildId);
  const channelName = `${category.channelPrefix}-${ticketNumber
    .toString()
    .padStart(4, "0")}`;

  const permissionOverwrites = [
    {
      id: interaction.guild.roles.everyone.id,
      deny: [PermissionFlagsBits.ViewChannel],
    },
    {
      id: interaction.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
      ],
    },
    {
      id: guildConfig.staff_role_id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.ManageChannels,
      ],
    },
    {
      id: interaction.client.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ManageChannels,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    },
  ];

  const channel = await interaction.guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: guildConfig.ticket_category_id || undefined,
    permissionOverwrites,
    topic: `Ticket de ${interaction.user.tag} | categoria:${categoryId} | usuario:${interaction.user.id}`,
  });

  db.createTicket({
    channelId: channel.id,
    guildId: interaction.guildId,
    userId: interaction.user.id,
    category: categoryId,
    ticketNumber,
  });

  const embed = ticketWelcomeEmbed({
    user: interaction.user,
    category,
    ticketNumber,
  });
  const row = ticketControlRow({ claimed: false });

  await channel.send({
    content: `${interaction.user} | <@&${guildConfig.staff_role_id}>`,
    embeds: [embed],
    components: [row],
  });

  await interaction.editReply({
    content: `✅ Ticket criado: ${channel}`,
  });
}

module.exports = { handleCreateTicket };
