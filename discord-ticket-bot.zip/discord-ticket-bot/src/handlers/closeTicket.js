const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const db = require("../database/db");
const categories = require("../config/categories");
const { generateTranscript } = require("../utils/transcript");
const { COLOR } = require("../utils/embeds");

async function handleCloseButton(interaction) {
  const ticket = db.getTicket(interaction.channel.id);
  if (!ticket) {
    return interaction.reply({
      content: "Este canal não é um ticket válido.",
      ephemeral: true,
    });
  }

  const modal = new ModalBuilder()
    .setCustomId("ticket_close_modal")
    .setTitle("Fechar Ticket");

  const reasonInput = new TextInputBuilder()
    .setCustomId("close_reason")
    .setLabel("Motivo do fechamento (opcional)")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(500);

  modal.addComponents(new ActionRowBuilder().addComponents(reasonInput));
  await interaction.showModal(modal);
}

async function handleCloseModalSubmit(interaction) {
  const ticket = db.getTicket(interaction.channel.id);
  if (!ticket) {
    return interaction.reply({
      content: "Este canal não é um ticket válido.",
      ephemeral: true,
    });
  }

  const reason = interaction.fields.getTextInputValue("close_reason") || "Não informado";
  await interaction.deferReply();

  const guildConfig = db.getGuildConfig(interaction.guildId);
  const category = categories.find((c) => c.id === ticket.category);
  const opener = await interaction.client.users.fetch(ticket.user_id).catch(() => null);

  db.closeTicket(interaction.channel.id, interaction.user.id);

  // Gera o transcript em HTML
  const transcriptPath = await generateTranscript(interaction.channel, {
    ticketNumber: ticket.ticket_number,
    categoryLabel: category?.label || ticket.category,
    openerTag: opener?.tag || ticket.user_id,
    closerTag: interaction.user.tag,
  });

  const closeEmbed = new EmbedBuilder()
    .setColor(COLOR)
    .setTitle(`🔒 Ticket #${ticket.ticket_number} encerrado`)
    .addFields(
      { name: "Aberto por", value: opener ? `${opener}` : ticket.user_id, inline: true },
      { name: "Fechado por", value: `${interaction.user}`, inline: true },
      { name: "Motivo", value: reason }
    )
    .setTimestamp();

  await interaction.editReply({
    embeds: [closeEmbed],
    content: "Este canal será removido em 10 segundos. O transcript foi salvo nos logs.",
  });

  // Envia o transcript pro canal de logs configurado
  if (guildConfig?.log_channel_id) {
    const logChannel = interaction.guild.channels.cache.get(guildConfig.log_channel_id);
    if (logChannel) {
      const attachment = new AttachmentBuilder(transcriptPath, {
        name: `transcript-ticket-${ticket.ticket_number}.html`,
      });
      await logChannel.send({ embeds: [closeEmbed], files: [attachment] });
    }
  }

  // Envia DM ao usuário: aviso de fechamento + pedido de feedback
  if (opener) {
    const feedbackRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`feedback_${ticket.channel_id}_5`)
        .setLabel("⭐⭐⭐⭐⭐ Ótimo")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`feedback_${ticket.channel_id}_3`)
        .setLabel("⭐⭐⭐ Regular")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`feedback_${ticket.channel_id}_1`)
        .setLabel("⭐ Ruim")
        .setStyle(ButtonStyle.Danger)
    );

    await opener
      .send({
        embeds: [
          new EmbedBuilder()
            .setColor(COLOR)
            .setTitle(`Seu ticket #${ticket.ticket_number} foi encerrado`)
            .setDescription(
              `Motivo: ${reason}\n\nGostaríamos de saber como foi seu atendimento. Poderia avaliar?`
            ),
        ],
        components: [feedbackRow],
      })
      .catch(() => null); // usuário pode ter DMs fechadas
  }

  setTimeout(() => {
    interaction.channel.delete().catch(() => null);
  }, 10_000);
}

module.exports = { handleCloseButton, handleCloseModalSubmit };
