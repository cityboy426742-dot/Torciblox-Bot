const { EmbedBuilder } = require("discord.js");
const db = require("../database/db");
const { ticketControlRow, COLOR } = require("../utils/embeds");

async function handleClaimTicket(interaction) {
  const ticket = db.getTicket(interaction.channel.id);
  if (!ticket) {
    return interaction.reply({
      content: "Este canal não é um ticket válido.",
      ephemeral: true,
    });
  }

  const guildConfig = db.getGuildConfig(interaction.guildId);
  const isStaff = interaction.member.roles.cache.has(guildConfig?.staff_role_id);
  if (!isStaff) {
    return interaction.reply({
      content: "Apenas membros da equipe podem assumir tickets.",
      ephemeral: true,
    });
  }

  if (ticket.status === "claimed") {
    return interaction.reply({
      content: `Este ticket já foi assumido por <@${ticket.claimed_by}>.`,
      ephemeral: true,
    });
  }

  db.claimTicket(interaction.channel.id, interaction.user.id);

  // Restringe o envio de mensagens da staff apenas para quem assumiu (mantendo o dono do ticket).
  await interaction.channel.permissionOverwrites.edit(guildConfig.staff_role_id, {
    SendMessages: false,
  });
  await interaction.channel.permissionOverwrites.edit(interaction.user.id, {
    ViewChannel: true,
    SendMessages: true,
    ReadMessageHistory: true,
  });

  const embed = new EmbedBuilder()
    .setColor(COLOR)
    .setDescription(`🙋 Ticket assumido por ${interaction.user}.`);

  await interaction.reply({ embeds: [embed] });

  // Atualiza os botões na mensagem original de controle, se possível.
  const messages = await interaction.channel.messages.fetch({ limit: 20 });
  const controlMsg = messages.find(
    (m) => m.author.id === interaction.client.user.id && m.components.length > 0
  );
  if (controlMsg) {
    await controlMsg.edit({ components: [ticketControlRow({ claimed: true })] });
  }
}

module.exports = { handleClaimTicket };
