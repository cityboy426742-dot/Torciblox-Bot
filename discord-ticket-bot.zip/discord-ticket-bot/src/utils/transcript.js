const path = require("node:path");
const fs = require("node:fs");

const outDir = path.join(__dirname, "..", "..", "transcripts");
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

function escapeHtml(str = "") {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/**
 * Busca todas as mensagens de um canal (paginando de 100 em 100) em ordem cronológica.
 */
async function fetchAllMessages(channel) {
  let messages = [];
  let lastId;

  while (true) {
    const options = { limit: 100 };
    if (lastId) options.before = lastId;
    const batch = await channel.messages.fetch(options);
    if (batch.size === 0) break;
    messages.push(...batch.values());
    lastId = batch.last().id;
    if (batch.size < 100) break;
  }

  return messages.reverse();
}

/**
 * Gera um arquivo HTML de transcript e retorna o caminho do arquivo salvo.
 *
 * NOTA SOBRE HOSPEDAGEM EM NUVEM:
 * Este helper salva o transcript localmente em /transcripts. Para hospedar como
 * no exemplo (transcripts.swaggergroup.com.br/transcripts/...), basta fazer um
 * upload desse HTML para o seu próprio servidor/bucket (S3, VPS com Nginx, etc)
 * logo após a geração — veja o comentário "UPLOAD_HOOK" abaixo para plugar isso.
 */
async function generateTranscript(channel, ticketInfo) {
  const messages = await fetchAllMessages(channel);

  const messagesHtml = messages
    .map((m) => {
      const avatar = m.author.displayAvatarURL({ size: 64 });
      const timestamp = new Date(m.createdTimestamp).toLocaleString("pt-BR");
      const content = escapeHtml(m.content || "");
      const attachments = [...m.attachments.values()]
        .map((a) => {
          if (a.contentType?.startsWith("image/")) {
            return `<div class="attachment"><img src="${a.url}" alt="anexo" /></div>`;
          }
          return `<div class="attachment"><a href="${a.url}" target="_blank">📎 ${escapeHtml(
            a.name
          )}</a></div>`;
        })
        .join("");
      const embeds = m.embeds
        .map(
          (e) => `<div class="embed">
            ${e.title ? `<div class="embed-title">${escapeHtml(e.title)}</div>` : ""}
            ${e.description ? `<div class="embed-desc">${escapeHtml(e.description)}</div>` : ""}
          </div>`
        )
        .join("");

      return `
        <div class="message">
          <img class="avatar" src="${avatar}" />
          <div class="body">
            <div class="header">
              <span class="author">${escapeHtml(m.author.username)}</span>
              <span class="timestamp">${timestamp}</span>
            </div>
            <div class="content">${content}</div>
            ${attachments}
            ${embeds}
          </div>
        </div>`;
    })
    .join("\n");

  const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8" />
<title>Transcript - Ticket #${ticketInfo.ticketNumber}</title>
<style>
  body { background:#313338; color:#dbdee1; font-family: 'gg sans', Arial, sans-serif; margin:0; padding:0; }
  .header-bar { background:#2b2d31; padding:16px 24px; border-bottom:1px solid #1e1f22; }
  .header-bar h1 { margin:0; font-size:18px; }
  .header-bar p { margin:4px 0 0; color:#949ba4; font-size:13px; }
  .messages { padding: 16px 24px; max-width: 900px; margin: 0 auto; }
  .message { display:flex; gap:14px; padding:8px 0; }
  .avatar { width:40px; height:40px; border-radius:50%; flex-shrink:0; }
  .header { display:flex; align-items:baseline; gap:8px; }
  .author { font-weight:600; color:#f2f3f5; }
  .timestamp { font-size:11px; color:#949ba4; }
  .content { white-space:pre-wrap; word-break:break-word; margin-top:2px; }
  .attachment img { max-width:320px; border-radius:6px; margin-top:6px; }
  .embed { border-left:4px solid #5865f2; background:#2b2d31; padding:8px 12px; border-radius:4px; margin-top:6px; max-width:520px; }
  .embed-title { font-weight:600; margin-bottom:4px; }
  .embed-desc { font-size:14px; color:#dbdee1; }
</style>
</head>
<body>
  <div class="header-bar">
    <h1>Transcript — Ticket #${ticketInfo.ticketNumber} (${escapeHtml(ticketInfo.categoryLabel)})</h1>
    <p>Aberto por ${escapeHtml(ticketInfo.openerTag)} • Fechado por ${escapeHtml(
    ticketInfo.closerTag
  )} • ${new Date().toLocaleString("pt-BR")}</p>
  </div>
  <div class="messages">
    ${messagesHtml}
  </div>
</body>
</html>`;

  const fileName = `transcript-${channel.id}-${Date.now()}.html`;
  const filePath = path.join(outDir, fileName);
  fs.writeFileSync(filePath, html, "utf-8");

  // UPLOAD_HOOK: se quiser subir automaticamente para sua própria nuvem/CDN,
  // chame sua função de upload aqui, ex:
  // const publicUrl = await uploadToCloud(filePath, fileName);
  // e use publicUrl no embed de log em vez do anexo local.

  return filePath;
}

module.exports = { generateTranscript };
