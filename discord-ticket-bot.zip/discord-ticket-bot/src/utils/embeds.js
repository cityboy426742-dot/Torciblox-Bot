const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const categories = require("../config/categories");

const COLOR = 0x5865f2;

function panelEmbed() {
  return new EmbedBuilder()
    .setColor(COLOR)
    .setTitle("🎫 Central de Atendimento")
    .setDescription(
      "Selecione abaixo o motivo do seu ticket para abrir um canal privado com nossa equipe."
    );
}

function panelSelectRow() {
  const select = new StringSelectMenuBuilder()
    .setCustomId("ticket_create_menu")
    .setPlaceholder("Selecione uma categoria...")
    .addOptions(
      categories.map((c) => ({
        label: c.label,
        value: c.id,
        emoji: c.emoji,
        description: c.description,
      }))
    );
  return new ActionRowBuilder().addComponents(select);
}

function ticketWelcomeEmbed({ user, category, ticketNumber }) {
  return new EmbedBuilder()
    .setColor(COLOR)
    .setTitle(`Ticket #${ticketNumber} — ${category.label}`)
    .setDescription(
      `Olá ${user}, seu ticket foi criado com sucesso!\n\nDescreva sua solicitação com detalhes. Um membro da equipe assumirá o atendimento em breve.`
    )
    .setFooter({ text: category.label })
    .setTimestamp();
}

function ticketControlRow({ claimed }) {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("ticket_claim")
      .setLabel("Assumir Ticket")
      .setEmoji("🙋")
      .setStyle(ButtonStyle.Success)
      .setDisabled(claimed),
    new ButtonBuilder()
      .setCustomId("ticket_add_member")
      .setLabel("Adicionar Membro")
      .setEmoji("➕")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId("ticket_close")
      .setLabel("Fechar Ticket")
      .setEmoji("🔒")
      .setStyle(ButtonStyle.Danger)
  );
  return row;
}

module.exports = {
  COLOR,
  panelEmbed,
  panelSelectRow,
  ticketWelcomeEmbed,
  ticketControlRow,
};
