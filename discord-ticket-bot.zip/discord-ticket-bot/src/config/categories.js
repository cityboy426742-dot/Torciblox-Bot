/**
 * Categorias exibidas no menu de abertura de ticket (Menu Usuário).
 * Edite livremente: id (não pode repetir), label, emoji, description e prefixo do canal.
 */
module.exports = [
  {
    id: "suporte",
    label: "Suporte",
    emoji: "🛠️",
    description: "Dúvidas gerais e problemas técnicos",
    channelPrefix: "suporte",
  },
  {
    id: "compras",
    label: "Compras",
    emoji: "💳",
    description: "Comprar produtos ou serviços",
    channelPrefix: "compras",
  },
  {
    id: "duvidas",
    label: "Dúvidas",
    emoji: "❓",
    description: "Perguntas sobre o servidor",
    channelPrefix: "duvida",
  },
  {
    id: "denuncia",
    label: "Denúncia",
    emoji: "🚨",
    description: "Reportar um membro ou problema",
    channelPrefix: "denuncia",
  },
];
